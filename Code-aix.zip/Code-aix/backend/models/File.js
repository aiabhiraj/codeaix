const mongoose = require("mongoose");

const fileSchema = new mongoose.Schema({
  name: { type: String, required: true },
  text: { type: String },
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  project: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Project",
  },
  mainProjectId: { type: mongoose.Schema.Types.ObjectId, ref: 'MainProject', required: true },
  uploadedAt: { type: Date, default: Date.now },
  fileStatus: {
    type: String,
    default: "with project",
  },
});

const File = mongoose.model("File", fileSchema);
module.exports = File;
