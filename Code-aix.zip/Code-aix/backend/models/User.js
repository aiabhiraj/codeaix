const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    unique: false,
  },
  lastName: {
    type: String,
    unique: false,
  },
  email: {
    type: String,
  },
  password: {
    type: String,
  },
  status: {
    type: String,
    enum: ["enabled", "disabled"],
    default: "enabled",
  },
  packageStatus: {
    type: String,
    enum: ["freemium", "monthly", "weekly", "daily"],
    default: "freemium",
  },
  role: {
    type: String,
    enum: ["user", "admin"],
    default: "user",
  },
  location: {
    type: String,
    default: "UnitedState",
  },
  workflows: {
    type: Array,
  },
  botLanguage: {
    type: String,
    default: "English",
  },
  apiKey: {
    type: String
  }
});


UserSchema.pre("save", function (next) {
    this.password
      ? bcrypt
          .hash(this.password, 10)
          .then((encrypted) => {
            this.password = encrypted;
          })
  
          .finally(() => {
            next();
          })
      : next();
  });

  
UserSchema.statics.checkPassword = function (pass, hashedPass) {
    return bcrypt.compareSync(pass, hashedPass);
  };


module.exports = mongoose.model("User", UserSchema)
