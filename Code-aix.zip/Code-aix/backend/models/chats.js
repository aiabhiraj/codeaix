// story.model.js

const mongoose = require('mongoose');

const chatSchema = new mongoose.Schema({
  UserId: { type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true },
  chat: {
    type: Array,
  },
  projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'MainProject', required: true },
});

const Chat = mongoose.model('chats', chatSchema);

module.exports = Chat;
