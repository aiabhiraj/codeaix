// project.router.js
const express = require("express");
const router = express.Router();
const Project = require("../models/MainFolder");

// Route to get all projects
router.get("/", async (req, res) => {
  try {
    const projects = await Project.find();
    res.json(projects);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Route to create a new project
router.post("/", async (req, res) => {
  const { name, description, createdBy } = req.body;
  const newProject = new Project({ name, description, createdBy });

  try {
    const savedProject = await newProject.save();
    res.status(201).json(savedProject);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Route to get a specific project by ID
router.get("/:id", getProjectById, (req, res) => {
  res.json(res.project);
});

// Middleware function to get a project by ID
async function getProjectById(req, res, next) {
  try {
    const project = await Project.findById(req.params.id)

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    res.project = project;
    next();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// Route to update a specific project by ID
// router.put("/:id", getProjectById, async (req, res) => {
//     const { name, description } = req.body;
  
//     if (name) res.project.name = name;
//     if (description) res.project.description = description;
  
//     try {
//       const updatedProject = await res.project.save();
//       res.json(updatedProject);
//     } catch (err) {
//       res.status(400).json({ message: err.message });
//     }
// });

router.put("/:id", async (req, res) => {
  try {
    const updateproject = await Project.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true } // Return the updated project in the response
    );
    res.status(200).json(updateproject);
  } catch (err) {
    console.log(err);
    return res.status(500).json(err);
  }
});




module.exports = router;
