import LogoutIcon from "@mui/icons-material/Logout";
import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import MenuIcon from "@mui/icons-material/Menu";
import Toolbar from "@mui/material/Toolbar";
import DashboardIcon from "@mui/icons-material/Dashboard";
import { Grid } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import Typography from "@mui/material/Typography";

import FolderSpecialIcon from "@mui/icons-material/FolderSpecial";
import CircularProgress from "@mui/material/CircularProgress";
import { toast } from "react-toastify";
import MoreVertIcon from '@mui/icons-material/MoreVert';
import sessionstorage from "sessionstorage";
import { authActions } from "../redux-store";

const drawerWidth = 280;

function ResponsiveDrawer(props) {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const navBtn = sessionstorage.getItem("navBtn")

  const [selectedButton, setSelectedButton] = React.useState(navBtn?navBtn:"Insights");
  const dispatch = useDispatch();
  const [loading, setLoading] = React.useState(false);

  const navigateTo = useNavigate();

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };




  const handleLogout = async () => {
    localStorage.clear();
    navigateTo("/");
    await dispatch(authActions.logout());
    toast.success("Signed out successfully")
  };
 


    useEffect(() => {
      if(selectedButton === 'Dashboard') {
        sessionstorage.setItem("navBtn", selectedButton)
        navigateTo(`/dashboard/`)
      }
      if(selectedButton === 'blog') {
        sessionstorage.setItem("navBtn", selectedButton)
        navigateTo(`/blog`)
      }
      if(selectedButton === 'Chat') {
        
        sessionstorage.setItem("navBtn", selectedButton)
        navigateTo('/chat')
       
      }
      if(selectedButton === 'logo') {
        sessionstorage.setItem("navBtn", selectedButton)
        navigateTo(`/logo`)
      }
      if(selectedButton === 'translate') {
        sessionstorage.setItem("navBtn", selectedButton)
        navigateTo(`/translate`)
      }
      if(selectedButton === 'Others') {
        sessionstorage.setItem("navBtn", selectedButton)
        navigateTo(`/others`)
      }
      if(selectedButton === 'Logout') {
        handleLogout();
      }
      
    
    },[selectedButton])

  const drawer = (
    <div
      style={{
        background: "white",
        color: " rgba(255, 255, 255, 0.6)",
        height: "100%",
      }}
    >
      <Toolbar
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          background: "transparent",
        }}
      >
        <h1
        
          sx={{ mr: 2, display: { sm: "none" } }}
          style={{
            marginTop: "3%",
            fontWeight: "800",
            color: "black"
         
          }}
        >
          AIX AI Tools
        </h1>
      </Toolbar>
    
      <div style={{display:"flex", justifyContent:"center", alignItems:"center",}}>
      <div style={{display:"flex", alignItems:"center",flexDirection:"row",width:"230px", height:"65px", borderRadius:"12px", border:"1px solid rgba(220, 220, 220, 1)", padding:"0.5rem"}}>
      <img src="/logo-main.png" alt="bot" style={{width:"48px", height:"48px"}}/>
      <div style={{marginLeft:"0.5rem"}}>
        <h1 style={{fontSize:"14px", color:"black", lineHeight:"1px"}}>AIX AI TOOLS</h1>
        <p style={{padding:"0.5rem", width:"93px", fontSize:"10px",color:"black", background:"rgba(241, 241, 241, 1)"}}>GPT 3.5 Turbo</p>
      </div>
      </div>
      </div>
      <br />
      <div>
        <List>
          {[
            "Dashboard",
            "Chat",
            "blog",
            "logo",
            "translate",
            "Others",
            "Logout"
          ].map((text, index) => (
            <ListItem key={text}>
              <ListItemButton
                onClick={() => setSelectedButton(text)}
                style={{
                  background:
                    selectedButton === text
                      ? "rgba(86, 63, 216, 0.34)"
                      : "transparent",
                  borderRadius: selectedButton === text ? "22px" : "",
                  border: selectedButton === text ? "" : "",
                  color: "black",
                  width: "100%",
                }}
              >
                <ListItemIcon style={{ color: "#5e35b1" }}>
                  {index === 0 ? (
                    <img src="/insights.png" alt="Insights"
                      style={{
                        width: "17px",
                        height: "17px",
                      }}
                    />
                  ) : index === 1 ? (
                    <img src="/insights.png" alt="Chat"
                      style={{
                        width: "17px",
                        height: "17px",
                      }}
                    />
                  ) : index === 2 ? (
                    <img src="/insights.png" alt="Settings"
                      style={{
                        width: "17px",
                        height: "17px",
                      }}
                    />
                  ) : index === 3 ? (
                    <img src="/insights.png" alt="Update knowledge"
                      style={{
                        width: "17px",
                        height: "17px",
                      }}
                    />
                  ) : index === 4 ? (
                    <img src="/insights.png" alt="Custom Q&A"
                      style={{
                        width: "17px",
                        height: "17px",
                      }}
                    />
                  ) : index === 5 ? (
                    <img src="/insights.png" alt="Inbox Icon"
                    style={{
                      width: "17px",
                      height: "17px",
                    }}
                  />
                  ) : (
                    <FolderSpecialIcon />
                  )}
                </ListItemIcon>
                <Typography
                  style={{
                    fontWeight: selectedButton === text ? "600" : "400",
                    fontSize: "17px",
                    fontFamily: "Poppins, sans-serif",
                    color: selectedButton === text ?"rgba(86, 63, 216, 1)":'black',
                  }}
                >
                  {text}
                </Typography>
              </ListItemButton>
            </ListItem>
          ))}
        </List>
        <br />
      </div>
    </div>
  );
  const container =
    window !== undefined ? () => window().document.body : undefined;
  return (



    <Box sx={{ display: "flex" }}>
      {/* <CssBaseline /> */}
      <div style={{ width: '45%', zIndex: -1, height: '500px', position: 'absolute', right: 0, top: 0, pointerEvents: 'none' }}>
      
      <img src="/bg-big.png" style={{height:"auto", width:"100%", }}/>

    </div>
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
        }}
        style={{ background: "transparent", color: "black", height: "0px" }}
      >
        
      
        <Divider />
        <Toolbar sx={{ mr: 2, display: { sm: "none" } }}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="mailbox folders"
      >
        {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, // Better open performance on mobile.
          }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      {/* <Box
        component="main"
        sx={{ flexGrow: 1, p: 3, width: { sm: `calc(100% - ${drawerWidth}px)` } }}
      >
        <Toolbar  />
        <Dashboard />
      </Box> */}

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 0,
          pt: 5,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
        }}
      >
        {/* <Toolbar />
      <Dashboard />
      <MenuFooter /> */}
        {/* {
        props.component
      } */}

        {loading ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              height: "100vh",
              alignItems: "center",
            }}
          >
            {/* <CircularProgress /> */}
            <img src="/loading-2.gif" alt="gif" />
          </div>
        ) : (
          props.component
        )}
      </Box>
      {/* Include your MenuFooter component here */}
    </Box>
    
  );
}

ResponsiveDrawer.propTypes = {
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

export default ResponsiveDrawer;
