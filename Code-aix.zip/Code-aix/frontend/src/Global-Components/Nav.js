import React, {useState, useEffect} from "react";
import { useParams } from "react-router-dom";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
import { authActions } from "../redux-store";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import AuthPopup from "./auth-pop/Popup";
import { setLanguage } from "../redux-store/auth/actions";
import "./Nav.css"

function Nav() {
  const { user } = useSelector((state) => state.auth);
  const [open, setOpen] = React.useState(false);
  const dispatch = useDispatch();
  const handleOpenAuth = () => setOpen(true);
  const [selectedLanguage, setSelectedLanguage] = useState('English'); // Default language
  const language = useSelector((state) => state.language.language);

  const ProjectID = localStorage.getItem("projectID")

  const handleCloseAuth = () => {
    setOpen(false);
  };

  const navigateTo =useNavigate();

  const handleLogout = async () => {
    localStorage.clear();
    navigateTo("/");
    await dispatch(authActions.logout());
    toast.success("Signed out successfully");
  };

  const navigateToDashboard =() => {
    navigateTo(`/dashboard`)
  }

  useEffect(() => {
    const updateLanguage = async () => {
      await dispatch(setLanguage(selectedLanguage));
    };
      // Only update the language if it has changed
      updateLanguage();
    
  }, [selectedLanguage]);

  const handleLanguageChange = (event) => {
    setSelectedLanguage(event.target.value);
  };


  return (
    <div style={{background:"rgb(4 5 28)", padding:"2rem", backgroundSize:"cover", height:"30px"}}>     
  <a style={{ position: "absolute", left: 5, top: 30, left:100, display:"flex", alignItems:"center", cursor:"pointer", textDecoration:"none" }} href="/">
  <img src="/site-logo.png" style={{width:"29px", height:"29px", marginRight:"1rem"}} alt="logo" />
  <img src="/logo-title.png"  style={{width:"164px", height:"20px", }} alt="title" />
</a>

<div>
    <nav style={{ textAlign: "center", marginBottom: "25px",marginTop:"0rem" }}>
      
    <a
  href="/"
  className="nav-link"
  style={{
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "600",
    fontFamily: "Poppins, sans-serif",
    fontSize: "15px",
    textDecoration: "none",
    marginRight: "2rem",
  }}
>
  {language === 'English' ? 'Home' : 'Domov'}
</a>

<a
  href="/about"
  className="nav-link"
  style={{
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "600",
    fontFamily: "Poppins, sans-serif",
    fontSize: "15px",
    textDecoration: "none",
  }}
>
  {language === 'English' ? 'About Us' : 'O nás'}
</a>

<a
  href="/businessmodel"
  className="nav-link"
  style={{
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "600",
    fontFamily: "Poppins, sans-serif",
    fontSize: "15px",
    textDecoration: "none",
  }}
>
  {language === 'English' ? 'AI' : 'o AI'}
</a>

<a
  href="/contact"
  className="nav-link"
  style={{
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "600",
    fontFamily: "Poppins, sans-serif",
    fontSize: "15px",
    textDecoration: "none",
    marginRight: "2rem",
  }}
>
  {language === 'English' ? 'Features' : 'Funkcie'}
</a>

<a
  href="/blog"
  className="nav-link"
  style={{
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "600",
    fontFamily: "Poppins, sans-serif",
    fontSize: "15px",
    textDecoration: "none",
    marginRight: "2rem",
  }}
>
  {language === 'English' ? 'Blog' : 'Blog'}
</a>

<a
  href="/pricing"
  className="nav-link"
  style={{
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "600",
    fontFamily: "Poppins, sans-serif",
    fontSize: "15px",
    textDecoration: "none",
    marginRight: "2rem",
  }}
>
  {language === 'English' ? 'Pricing' : 'Cenník'}
</a>




      {user ? (

 <span style={{ position: "absolute", top: 25, right:100, cursor:"pointer", textDecoration:"none" }} href="/login">
        <a onClick={()=>navigateToDashboard()} className="nav-link"
        style={{ color: "white", marginTop:'1rem', height:"48px", background:"rgba(86, 63, 216, 1)", borderRadius:"8px",fontWeight:"600", borderColor:"transparent",fontFamily:"Poppins,sans-serif",fontSize:"13px", padding:"1rem", textDecoration: "none", cursor:"pointer" }}
        >
          Dashboard
        </a>
                </span>

      ) : (

        <span style={{ position: "absolute", top: 20, right:100, cursor:"pointer", textDecoration:"none" }} href="/login">
        
        <a href="/auth">
        <button className="nav-link"
        style={{ color: "white", height:"48px", background:"transparent", borderRadius:"8px",fontWeight:"600", borderColor:"transparent",fontFamily:"Poppins,sans-serif",fontSize:"13px", padding:"1rem", textDecoration: "none", cursor:"pointer" }}

        >
          Sign Up
        </button>
        </a>
        </span>
        
      )}

<span style={{ position: "absolute", top: 35, right:40, cursor:"pointer", textDecoration:"none" }} href="/login">
      
      <select value={selectedLanguage} onChange={handleLanguageChange}>
        <option value="English">English</option>
        <option value="Slovakia">Slovakia</option>
      </select>
    </span>
     
    </nav>

    <div>
    {open && <AuthPopup onClose={handleCloseAuth}/>}
    </div>
    </div>
    </div>
  );
}

export default Nav;
