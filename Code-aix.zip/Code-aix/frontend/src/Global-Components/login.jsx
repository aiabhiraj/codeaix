import React, { useState, useEffect } from "react";
import { Grid } from "@mui/material";
import { useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { authActions } from "../redux-store";
import CircularProgress from "@mui/material/CircularProgress";

function Login() {
  const [width, setWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1024);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isHuman, setIsHuman] = useState(false);
  const [state, setState] = useState(0);
  const [loading, setLoading] = useState(false);

  const handleChange = (value) => {
    if (value) {
      setIsHuman(true);
    } else {
      setIsHuman(false);
    }
  };

  const navigateTo = useNavigate();
  const dispatch = useDispatch();

  const SignUpHandler = async (e) => {
    e.preventDefault();
    setLoading(true)
    try {
      if(email !="" && email!=null && email !=undefined &&
      password !="" && password!=null && password !=undefined
      ) {
      if(email.includes("@")  && password.length>5) {
      const isSignup = await dispatch(
        authActions.signUp(email, password)
      );
      if (isSignup) {
        toast.success("Signed Up Successfully");
        setLoading(false)
        navigateTo("/dashboard")
      }
      if (!isSignup) {
        toast.error("Wrong credentials");
      }
    
  }
    else {
      toast.error('Enter correct email & password length>5')
    } 
    } else {
      toast.error('Enter correct email & password length>5')
    } 
    } catch (e) {
      toast.error("Network Error");
    }
  };
  
  const ForgotHandler = async (e) => {
    e.preventDefault();
    setLoading(true)
    try {
      const isforgot = await dispatch(authActions.forgotPassword(email));
       if (isforgot) {
        setLoading(false)
        toast.success('Password sent on email')

       } else {
        toast.error('Enter valid registered email')
       }
   }  catch (err) {
      toast.error('Network error')
    }
    }


  const loginSubmitHandler = async (e) => {
    e.preventDefault();
    setLoading(true)
    const isLogin = await dispatch(authActions.login(email, password));
    if (isLogin) {
      setLoading(false)
      navigateTo("/dashboard");
     
    } else {
      toast.error("Wrong credentials");
    }
  };



  useEffect(() => {
    setWidth(window.innerWidth);
    const updateDimensions = () => {
      setWidth(window.innerWidth);
    };
    window.addEventListener("resize", updateDimensions);

    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

 

  return (
    loading? <CircularProgress/>: <div style={{ minHeight: "100vh",padding:"1rem",  backgroundImage: 'url("/bg-1.PNG")' ,minWidth:"96vw", minHeight:"100vh", backgroundSize:"cover", backgroundPosition:"center", backgroundRepeat:"no-repeat", zIndex:-1}}>
      <Grid container columns={12}>
      <Grid item xs={12} sm={12} md={2}>

      </Grid>
        <Grid item xs={12} sm={12} md={8} >
          <h1 style={{ color: "white", fontSize: "52px" }}>
           {state==0?"Hello!":state==1?"Sign up":"Forgot Password"}
          </h1>
          <p style={{ color: "#E4E4E7", fontSize: "18px" }}>Welcome to ITIX. Community Dashboard</p>
          <div style={{ marginTop: "3%" }}>
            <label style={{ color: "#E4E4E7", marginLeft: "10px", fontSize: "16px" }}>Email Address</label>
            <br />
            <input
              style={{
                color: "white",
                marginTop: "10px",
                width: "40%",
                height: "30px",
                borderColor: "#4587F6",
                borderRadius: "10px",
                background: "transparent",
                padding: "0.5rem",
              }}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email"
            />
            <br />
            <br />
            {state==2?null:
            <div>
            <label style={{ color: "#E4E4E7", marginLeft: "10px", fontSize: "16px" }}>Password</label>
            <br />
          
            <input
              type="password"
              style={{
                color: "white",
                marginTop: "10px",
                width: "40%",
                height: "30px",
                borderColor: "#4587F6",
                borderRadius: "10px",
                background: "transparent",
                padding: "0.5rem",
              }}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
            />
            </div>
            }
          </div>

          {state===0?
          <button
            style={{
              marginTop: "40px",
              width: "40%",
              height: "30px",
              borderColor: "transparent",
              borderRadius: "10px",
              color: "White",
              marginBottom: "30px",
              cursor: "pointer",
              background: "linear-gradient(270deg, #0690FF 0%, #0083EC 50.35%, #027BDD 100%), #2563EB",
            }}
            onClick={(e) => loginSubmitHandler(e)}
          >
            Login
          </button>: state==1?<button
           style={{
             marginTop: "40px",
             width: "40%",
             height: "30px",
             borderColor: "transparent",
             borderRadius: "10px",
             color: "White",
             marginBottom: "30px",
             cursor: "pointer",
             background: "linear-gradient(270deg, #0690FF 0%, #0083EC 50.35%, #027BDD 100%), #2563EB",
           }}
           onClick={(e) => SignUpHandler(e)}
         >
           Signup
         </button>:  <button
            style={{
              marginTop: "40px",
              width: "40%",
              height: "30px",
              borderColor: "transparent",
              borderRadius: "10px",
              color: "White",
              marginBottom: "30px",
              cursor: "pointer",
              background: "linear-gradient(270deg, #0690FF 0%, #0083EC 50.35%, #027BDD 100%), #2563EB",
            }}
            onClick={(e) => ForgotHandler(e)}
          >
            Forgot
          </button>}
         
          <div style={{ textAlign: "center", width: "40%" }}>
            {state==0?
              <p style={{ color: "#D0D3D6", fontWeight: "400", fontSize: "14px" }}>
                Don't have an account? <a onClick={()=>setState(1)} style={{ color: "aqua" }}>Sign up</a>
              </p>:
              
              <p style={{ color: "#D0D3D6", fontWeight: "400", fontSize: "14px" }}>
                Have an account? <a onClick={()=>setState(0)} style={{ color: "aqua" }}>Login</a>
              </p>}
              <hr style={{ width: "50%" }} />
              <p style={{ color: "#D0D3D6", fontWeight: "400", fontSize: "14px" }}>
                <a onClick={()=>setState(2)} style={{ color: "aqua" }}>Forgot Password</a>
              </p>
          </div>
        </Grid>

       
      </Grid>
    </div>
  );
}

export default Login;
