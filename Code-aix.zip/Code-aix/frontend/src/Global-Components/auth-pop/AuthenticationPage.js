import React, { useState } from 'react';
import { useDispatch } from 'react-redux';

import AuthPopup from './Popup';
import Menu from '../Menu';

const AuthenticationPage = (props) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullname, setFullname] = useState('');
  const [isChecked, setIsChecked] = useState(false);
  const dispatch = useDispatch();

  const [open, setOpen] = React.useState(true);
  const handleOpenAuth = () => setOpen(true);
  const handleCloseAuth = () => {
    setOpen(false);
  };


  return (
    <div>
      <Menu />
    <div  style={{ height:"100vh",  display:"flex", justifyContent:"center"}}>
      <button onClick={()=>setOpen(true)} style={{ backgroundColor:"black",fontWeight:"600",cursor:"pointer",fontSize:"20px",display:"flex", justifyContent:"center", alignContent:"center", justifyItems:"center", padding:"1rem", borderRadius:"15px", height:"70px", marginTop:"15rem"}}>
        
        <span style={{color:"white", marginRight:"0.5rem"}}>Login to </span> <span style={{color:"rgba(23, 42, 55, 1)", marginRight:"0.5rem"}}>Angola</span> <span style={{color:"rgb(255 185 0)", }}>Spots</span>
        
        </button>
      {open && <AuthPopup onClose={handleCloseAuth}/>}
    </div>
    </div>
  );
};

export default AuthenticationPage;
