import React, {useState,useEffect} from 'react';
import { Grid } from '@mui/material';
import { useSelector } from 'react-redux';



function Section3() {
    const [width, setWidth] = useState(window.innerWidth);
    const language = useSelector((state) => state.language.language);

    const updateDimensions = () => {
      setWidth(window.innerWidth);
    };
    useEffect(() => {
      window.addEventListener("resize", updateDimensions);
      return () => window.removeEventListener("resize", updateDimensions);
    }, []);


    return (

        <div style={{paddingLeft:width>800?"6rem":"2rem", paddingRight:width>800?"6rem":"2rem", paddingTop:"4rem"}} >
       
       <h1 style={{
              color: "#FFF",
              fontSize: "42px",
              fontWeight: "700",
              fontFamily: "sans-serif, inter",
              marginRight:"1rem"
            }}>
        {language === 'English' ? 'Features' : 'Funkcie'}
       </h1>
       <Grid container columns={12} columnGap={2} style={{marginTop:"1rem"}}>
      
       <Grid items xs={6} md={2.5} sm={6}>
        <p style={{padding:"1rem", fontSize:"22px", boxShadow:"rgba(47, 21, 244, 1)", borderRadius:"10px", fontWeight:"700", textAlign:"center", border:"1px solid rgba(69, 135, 246, 1)"}}>
        ITIX COPYWRITING
        </p>
        </Grid> 

        <Grid items xs={6} md={2.5} sm={6}>
        <p style={{padding:"1rem", fontSize:"22px", boxShadow:"rgba(47, 21, 244, 1)", borderRadius:"10px", fontWeight:"700", textAlign:"center", border:"1px solid rgba(69, 135, 246, 1)"}}>
        ITIX COPYWRITING
        </p>
        </Grid> 
        <Grid items xs={6} md={2.5} sm={6}>
        <p style={{padding:"1rem", fontSize:"22px", boxShadow:"rgba(47, 21, 244, 1)", borderRadius:"10px", fontWeight:"700", textAlign:"center", border:"1px solid rgba(69, 135, 246, 1)"}}>
        ITIX AI CONSULT
        </p>
        </Grid> 
        <Grid items xs={6} md={2.5} sm={6}>
        <p style={{padding:"1rem", fontSize:"22px", boxShadow:"rgba(47, 21, 244, 1)", borderRadius:"10px", fontWeight:"700", textAlign:"center", border:"1px solid rgba(69, 135, 246, 1)"}}>
        ITIX AI CONSULT
        </p>
        </Grid> 
       </Grid>

       <Grid container columns={12} columnGap={2} style={{marginTop:"2rem"}}>

        <Grid item sm={12} xs={12} md={5} style={{textAlign:"left"}}>
        <h1 style={{
  color: "#FFF",
  fontSize: "42px",
  fontWeight: "700",
  fontFamily: "sans-serif, inter",
}}>
  {language === 'English' ? 'AIX and Connection to Your Business' : 'AIX a prepojenie s vašim podnikaním'}
  <span
    style={{
      color: "#3e63f5",
      fontSize: "42px",
      fontWeight: "700",
      fontFamily: "sans-serif, inter",
      marginLeft: "1rem"
    }}
  > </span>
</h1>

<p style={{ color: "#A0AEC0", fontSize: "18px" }}>
  {language === 'English' ?
    <p>ITIX Community token is a tool that represents ITIX Technologies. <br /><br />1. Phase helps finance and create projects and connect them to the community. <br /><br />2. Phase ITIX TECHNOLOGIES and Community token have a profit share from created projects, which will bring value and cash flow to the company and the community token. In the long run, this could bring stable cash flow to the project. <br /><br />3. Phase is the opening of the ITIX incubator, where anyone can apply with their project, and ITIX, under certain conditions, can support the development, marketing, and project management.</p>
    :
    <p>ITIX Community token je nástroj, ktorý predstavuje ITIX Technologies. <br /><br />1. Fáza pomáha financovať a tvoriť projekty a prepájať ich s komunitou. <br /><br />2. Fáza ITIX TECHNOLOGIES a Community token má profitshare z vytvorených projektov, čo bude prinášať hodnotu a cashflow do firmy a do community tokenu. Z dlhodobého hľadiska by to mohlo prinášať stabilný cashflow do projektu. <br /><br />3. Fáza je otvorenie ITIX inkubátora, do ktorého sa môže ktokoľvek prihlásiť so svojim projektom a ITIX za určitých podmienok vie zastrešiť vývoj, marketing a managment projektu.</p>
  }
</p>

 </Grid>

        <Grid item sm={12} xs={12} md={6} style={{textAlign:"right"}}>
            <img style={{height:width>800?"auto":"400px", width:width>800?"auto":"300px"}} src="/section2.png" alt="section2 Image" />
        </Grid>
        <Grid items xs={6} md={2.5} sm={6} >
        <p style={{padding:"1rem", fontSize:"16px", boxShadow:"rgba(47, 21, 244, 1)", borderRadius:"10px", fontWeight:"700", textAlign:"center", border:"1px solid rgba(69, 135, 246, 1)"}}>
       View More
        </p>
        </Grid> 
       </Grid>

    
   
       </div>
    )
}


export default Section3;