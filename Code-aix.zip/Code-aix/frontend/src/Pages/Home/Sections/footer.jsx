import React, {useState, useEffect} from 'react';
import './footer.css';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import FacebookIcon from '@mui/icons-material/Facebook';
import DoneIcon from '@mui/icons-material/Done';
import { useSelector } from 'react-redux';


const Footer = () => {


    const [width, setWidth] = useState(window.innerWidth);

    const updateDimensions = () => {
        setWidth(window.innerWidth);
      };
      useEffect(() => {
        window.addEventListener("resize", updateDimensions);
        return () => window.removeEventListener("resize", updateDimensions);
      }, []);

  return (
    <footer className="footer">
      <div className="footer-container">
        {width >700?
        <div className="footer-left">
          <img src='/logo-main.png' />
        </div>:null}
        <div className="footer-center">
          <h2>Quick Links</h2>
          <ul>
            <li>FAQ</li>
            <li>Privacy</li>
            <li>Terms</li>
            <li>Guidelines</li>
<li>Acceptable Use Policy</li>
<li>Law Enforcement Policy</li>


          </ul>
        </div>
        <div className="footer-right">
        <h2>{"Follow Us"}</h2>
          <div className="social-icons">
            <i className="fab fa-facebook">
            <FacebookIcon />
            </i>
            <i className="fab fa-twitter">
                <TwitterIcon />
            </i>
            <i className="fab fa-instagram">
                <InstagramIcon />
            </i>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
