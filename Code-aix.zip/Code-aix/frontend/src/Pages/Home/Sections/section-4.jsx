import React, {useState,useEffect} from 'react';
import { Grid } from '@mui/material';
import { useSelector } from 'react-redux';



function MySection4() {
    const [width, setWidth] = useState(window.innerWidth);
    const language = useSelector((state) => state.language.language);

    const updateDimensions = () => {
      setWidth(window.innerWidth);
    };
    useEffect(() => {
      window.addEventListener("resize", updateDimensions);
      return () => window.removeEventListener("resize", updateDimensions);
    }, []);


    return (

        <div style={{ paddingLeft: width > 800 ? '6rem' : '2rem', paddingRight: width > 800 ? '6rem' : '2rem', paddingTop: '1rem' }}>
        
        <h1  style={{
              color: "#FFF",
              fontSize: "42px",
              fontWeight: "700",
              fontFamily: "sans-serif, inter",
              marginRight:"1rem"
            }} >
            Všetky funkcie
           
            </h1>
        <Grid container columns={12} style={{ marginTop: '4rem' }}>
          <Grid item xs={12} md={3} style={{ textAlign: 'left' }}>
            <img
              style={{ height: width > 800 ? 'auto' : '400px', width: width > 800 ? 'auto' : '300px' }}
              src="/section4_1.png"
              alt="section1 Image"
            />
          </Grid>
  
          <Grid item xs={12} md={8} style={{ textAlign: 'left' }}>
            
            <h1  style={{
              color: "#FFF",
              fontSize: "24px",
              fontWeight: "700",
              fontFamily: "sans-serif, inter",
              marginRight:"1rem"
            }} >
            {language === 'English' ? 'AIX Graphics Creation' : 'AIX vytváranie grafiky'}
</h1>
            <p style={{color:"#FFF", fontSize:"18px"}}>
            {language === 'English' ? "ITIX SOCIAL NETWORK is an advanced social network of the 21st century that brings a new era to the online environment." : "ITIX SOCIAL NETWORK je pokroková sociálna sieť 21. storočia, ktorá prináša novú éra online prostrediu."}
            </p>
            <br/> <br/>
            <p style={{color:"#A0AEC0", fontSize:"18px"}}>
            <span style={{ color: "#FFF", fontSize: "18px" }}>
  {language === 'English' ? 'Influence Section:' : 'Influence časť:'}
</span> {language === 'English' ? 'Opens doors for influencers to earn without unnecessary products and build income by creating meaningful content. ITIX SOCIAL NETWORK includes modules for podcasts, courses, live consultations, a marketplace, advertising, and a custom eshop for influencers. It also includes paid posts, photos, videos, and paid groups. In the end, it has everything an influencer or mentor needs to run, maintain, and build their own community.' : 'Otvára dvere influencerom zarábať bez zbytočných produktov a budovať príjem tvorením zmysluplnému kontentu. ITIX SOCIAL NETWORK obsahuje moduly pre podcasty, kurzy, živé konzultácie, trhovisko, reklamu a vlastný eshop pre influencerov. Obsahuje aj platené príspevky, fotky, videá a platené skupiny. Na konci obsahuje všetko, čo influencer alebo mentor potrebuje na prevádzku, udržiavanie a budovanie vlastnej komunity.'}
<br /><br />
<span style={{ color: "#FFF", fontSize: "18px" }}>
  {language === 'English' ? 'User Section:' : 'Užívateľská časť:'}
</span>
{language === 'English' ? 'Brings users an online environment that is not cluttered with ads and, thanks to all the modules, keeps followers in close contact with the influencer.' : 'Prináša užívateľom online prostredie, ktoré nie je preplnené reklamami a vďaka všetkým modulom udržuje sledovateľov v úzkom kontakte s influencerom.'}
</p> 
</Grid>
        </Grid>
  
        <Grid container columns={12} style={{ marginTop: '4rem' }}>
          <Grid item xs={12} md={8} style={{ textAlign: 'left' }}>
          <h1 style={{
  color: "#FFF",
  fontSize: "24px",
  fontWeight: "700",
  fontFamily: "sans-serif, inter",
  marginRight: "1rem"
}}>
  {language === 'English' ? 'AIX Copywriting' : 'AIX copywritting'}
</h1>
<p style={{ color: "#FFF", fontSize: "18px" }}>
  {language === 'English' ?
    'As of today, we count thousands of amateur projects with artificial intelligence. However, none of them is complex enough to cover everything a user needs in the online interface for building their projects, from marketing through development to gadgets.' :
    'Ku dnešnému dňu počítame amatérske projekty s umelou inteligenciou na tisícky. Avšak žiadny z nich nie je dosť komplexný, aby zastrešil všetko, čo užívateľ potrebuje v internetovom rozhraní na budovanie svojich projektov od marketingu cez vývoj až po vychytávky.'}
</p>
<p style={{ color: "#A0AEC0", fontSize: "18px" }}>
  {language === 'English' ?
    'ITIX AI TOOLS brings the necessary AI tools in one platform, from marketing strategies, graphic work to development, and many other tools needed for business development.' :
    'ITIX AI TOOLS prináša potrebné AI nástroje v jednej platforme od marketingových stratégií, grafických prác až po vývoj a mnoho ďalších nástrojov potrebných na business development.'}
</p>

          </Grid>
  
          <Grid item xs={12} md={3} style={{ textAlign: 'left' }}>
            <img
              style={{ height: width > 800 ? 'auto' : '400px', width: width > 800 ? 'auto' : '300px' }}
              src="/section4_2.png"
              alt="section2 Image"
            />
          </Grid>
        </Grid>

        <Grid container columns={12} style={{ marginTop: '4rem' }}>
          <Grid item xs={12} md={3} style={{ textAlign: 'left' }}>
            <img
              style={{ height: width > 800 ? 'auto' : '400px', width: width > 800 ? 'auto' : '300px' }}
              src="/section4_3.png"
              alt="section1 Image"
            />
          </Grid>
  
          <Grid item xs={12} md={8} style={{ textAlign: 'left' }}>
          <h1 style={{
  color: "#FFF",
  fontSize: "24px",
  fontWeight: "700",
  fontFamily: "sans-serif, inter",
  marginRight: "1rem"
}}>
  {language === 'English' ? 'AIX Consultations with Artificial Intelligence' : 'AIX konzultácie s umelou inteligenciou'}
</h1>
<p style={{ color: "#FFF", fontSize: "18px" }}>
  {language === 'English' ?
    'There are many products and services that have not been summarized and publicly available on a single platform for everyone.' :
    'Je mnoho produktov a služieb ktoré do dnešného dňa nie sú zosumarizované a verejne dostupné na jednej platforme pre každého.'}
</p>
<p style={{ color: "#A0AEC0", fontSize: "18px" }}>
  {language === 'English' ?
    'It is a set of platforms bringing products, services, and solutions that have not been summarized in any platforms. We will connect the whole world with it.' :
    'Je súbor platforiem prinášajúci produkty služby a riešenia ktoré nie sú zosumarizované v žiadnych platformách. Prepojíme tým celý svet.'}
</p>
 </Grid>
        </Grid>

        <Grid container columns={12} style={{ marginTop: '4rem' }}>
          <Grid item xs={12} md={8} style={{ textAlign: 'left' }}>
          
          <h1 style={{
  color: "#FFF",
  fontSize: "24px",
  fontWeight: "700",
  fontFamily: "sans-serif, inter",
  marginRight: "1rem"
}}>
  {language === 'English' ? 'AIX X-Chat' : 'AIX X-Chat'}
</h1>
<p style={{ color: "#FFF", fontSize: "18px" }}>
  {language === 'English' ?
    'The year 2023 is the year of automation and artificial intelligence. People still pay thousands of euros annually for services and products that are already created or can be created by AI in a matter of seconds.' :
    'Rok 2023 je rok automatizácie a umelej inteligencie. Ľudia aj tak platia tisíce eur ročne za služby a produkty, ktoré sú už vytvorené alebo ich vie AI do niekoľkých sekúnd vytvoriť.'}
</p>
<p style={{ color: "#A0AEC0", fontSize: "18px" }}>
  {language === 'English' ?
    'ITIX ADMIN is a drag-and-drop solution for web development and module implementation. ITIX ADMIN offers easy and from the comfort of your home online rental solutions and open-source advanced codes.' :
    'ITIX ADMIN je Drag and drop riešenie, ktoré slúži na web development a implementáciu modulov. ITIX ADMIN prináša jednoducho a z komfortu domova online riešenia na prenájom a opensource pokročilých kódov.'}
</p>
  </Grid>
  
          <Grid item xs={12} md={3} style={{ textAlign: 'left' }}>
            <img
              style={{ height: width > 800 ? 'auto' : '400px', width: width > 800 ? 'auto' : '300px' }}
              src="/section4_4.png"
              alt="section2 Image"
            />
          </Grid>
        </Grid>

        <Grid container columns={12} style={{ marginTop: '4rem' }}>
          <Grid item xs={12} md={3} style={{ textAlign: 'left' }}>
            <img
              style={{ height: width > 800 ? 'auto' : '400px', width: width > 800 ? 'auto' : '300px' }}
              src="/section4_5.png"
              alt="section1 Image"
            />
          </Grid>
  
          <Grid item xs={12} md={8} style={{ textAlign: 'left' }}>
          <h1 style={{
  color: "#FFF",
  fontSize: "24px",
  fontWeight: "700",
  fontFamily: "sans-serif, inter",
  marginRight: "1rem"
}}>
  {language === 'English' ? 'AIX Translations' : 'AIX preklady'}
</h1>
<p style={{ color: "#FFF", fontSize: "18px" }}>
  {language === 'English' ?
    'There are many products and services that have not been summarized and made publicly available on a single platform for everyone.' :
    'Je mnoho produktov a služieb, ktoré doteraz neboli zhrnuté a verejne dostupné na jednej platforme pre každého.'}
</p>
<p style={{ color: "#A0AEC0", fontSize: "18px" }}>
  {language === 'English' ?
    'It is a set of platforms that bring products, services, and solutions that have not been summarized on any platforms. We will connect the whole world with it.' :
    'Je to súbor platforiem, ktoré prinášajú produkty, služby a riešenia, ktoré neboli zhrnuté na žiadnej platforme. Prepojíme ním celý svet.'}
</p>

          </Grid>
        </Grid>

      </div>
    )
}


export default MySection4;