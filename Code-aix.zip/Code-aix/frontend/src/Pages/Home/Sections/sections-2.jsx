import React, { useState, useEffect } from 'react';
import { Grid } from '@mui/material';
import { useSelector } from 'react-redux';

function Section2() {
  const [width, setWidth] = useState(window.innerWidth);
  const language = useSelector((state) => state.language.language);

  const updateDimensions = () => {
    setWidth(window.innerWidth);
  };

  useEffect(() => {
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  return (
    <div style={{ paddingLeft: width > 800 ? "6rem" : "2rem", background: "#060626", paddingRight: width > 800 ? "6rem" : "2rem", paddingTop: "1rem" }}>
      <Grid container columns={12} columnGap={2}>
        <Grid item sm={12} xs={12} md={5} style={{ textAlign: "left" }}>
          <h1
            style={{
              color: "#FFF",
              fontSize: "42px",
              fontWeight: "700",
              fontFamily: "sans-serif, inter",
              marginRight: "1rem",
            }}
          >
            {language === 'English' ? 'Utilization' : 'Využitie'}
            <span
              style={{
                color: "#3e63f5",
                fontSize: "42px",
                fontWeight: "700",
                fontFamily: "sans-serif, inter",
              }}
            > AIX</span>
          </h1>
          <p style={{ color: "#A0AEC0", fontSize: "18px" }}>
            {language === 'English' ?
              "We are a team of innovative developers with rich experience in the IT environment. We master advanced programming and marketing strategies that are essential for development. We have joined forces for the vision of quality development, not only for clients but also for the development of our own projects. As developers, we have encountered many creative ideas that have not been completed. Therefore, we decided to launch the ITIX project to provide quality services to our clients and demonstrate the quality of our KNOW HOW in ITIX projects."
              :
              "Sme tím inovatívnych vývojárov s bohatými skúsenosťami z IT prostredia. Ovládame pokročilé programátorské a marketingové stratégie, ktoré sú dôležité pri developmente. Spojili sme sa za účelom vízie kvalitného developmentu nie len pre klientov, ale aj developmentu vlastných projektov. Ako vývojári sme sa stretli s mnoho kreatívnymi nápadmi nedotiahnutými do konca. Preto sme sa rozhodli otvoriť projekt ITIX aby sme prinášali kvalitné služby pre našich klientov a zároveň ukázali kvalitu nášho KNOW HOW v ITIX projektoch."
            }
          </p>
        </Grid>

        <Grid item sm={12} xs={12} md={6} style={{ textAlign: "right" }}>
          <img style={{ height: width > 800 ? "auto" : "400px", width: width > 800 ? "auto" : "300px" }} src="/section2.png" alt="section2 Image" />
        </Grid>
      </Grid>

      <h1 style={{
        color: "#FFF",
        fontSize: "42px",
        fontWeight: "700",
        fontFamily: "sans-serif, inter",
        marginRight: "1rem"
      }}>
        {language === 'English' ? 'Features' : 'Funkcie'}
      </h1>
      <Grid container columns={12} columnGap={2} style={{ marginTop: "1rem" }}>

        {/* Render your feature items here */}
        {/* You can use the same approach to conditionally render English/Slovak for feature names and descriptions */}
      </Grid>

      <Grid container columns={12} columnGap={2} style={{ marginTop: "4rem" }}>
        <Grid item sm={12} xs={12} md={6} style={{ textAlign: "left" }}>
          <img style={{ height: width > 800 ? "auto" : "400px", width: width > 800 ? "auto" : "300px" }} src="/section2.png" alt="section2 Image" />
        </Grid>

        <Grid item sm={12} xs={12} md={5} style={{ textAlign: "left" }}>
          <h1
            style={{
              color: "#FFF",
              fontSize: "42px",
              fontWeight: "700",
              fontFamily: "sans-serif, inter",
              marginRight: "1rem",
            }}
          >
            {language === 'English' ? 'Utilization' : 'Využitie'}
            <span
              style={{
                color: "#3e63f5",
                fontSize: "42px",
                fontWeight: "700",
                fontFamily: "sans-serif, inter",
              }}
            > AIX</span>
          </h1>
          <p style={{ color: "#A0AEC0", fontSize: "18px" }}>
            {language === 'English' ?
              "We are a team of innovative developers with rich experience in the IT environment. We master advanced programming and marketing strategies that are essential for development. We have joined forces for the vision of quality development, not only for clients but also for the development of our own projects. As developers, we have encountered many creative ideas that have not been completed. Therefore, we decided to launch the ITIX project to provide quality services to our clients and demonstrate the quality of our KNOW HOW in ITIX projects."
              :
              "Sme tím inovatívnych vývojárov s bohatými skúsenosťami z IT prostredia. Ovládame pokročilé programátorské a marketingové stratégie, ktoré sú dôležité pri developmente. Spojili sme sa za účelom vízie kvalitného developmentu nie len pre klientov, ale aj developmentu vlastných projektov. Ako vývojári sme sa stretli s mnoho kreatívnymi nápadmi nedotiahnutými do konca. Preto sme sa rozhodli otvoriť projekt ITIX aby sme prinášali kvalitné služby pre našich klientov a zároveň ukázali kvalitu nášho KNOW HOW v ITIX projektoch."
            }
          </p>
        </Grid>
      </Grid>
    </div>
  );
}

export default Section2;
