import React,{useState, useEffect} from "react";
import { Grid } from "@mui/material";
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import PhoneIcon from '@mui/icons-material/Phone';
import PlaceIcon from '@mui/icons-material/Place';

function Contact() {

    const [width, setWidth] = useState(window.innerWidth);
    const [switchValue, setSwitchValue] = useState(false);

    const handleSwitchChange = (event) => {
      setSwitchValue(event.target.checked);
    };
    console.log(switchValue);

    const updateDimensions = () => {
      setWidth(window.innerWidth);
    };
    useEffect(() => {
      window.addEventListener('resize', updateDimensions);
      return () => window.removeEventListener('resize', updateDimensions);
    }, []);


    const boxStyles = {
        marginTop: "1rem",
        background: "transparent",
        padding: "32px 40px",
        height: "auto",
        width: "1110px",
        borderRadius: "20px",
        boxShadow: "0 4px 8px rgba(16, 24, 40, 0.1)",
      };

  return (
    <section style={{ minHeight: "100vh", padding: width > 800 ? '2rem' : '2rem' }}>
      <div>
        <h1
          style={{
            fontWeight: "600",
            fontSize: width > 800 ? "36px" : "25px",
            fontFamily: "Hellix, sans-serif",
            display: "flex",
            justifyContent: "center",
          }}
        >
         Referencie
        </h1>
        <p
          style={{
            fontWeight: "400",
            fontSize: width > 800 ? "16px" : "14px",
            fontFamily: "Poppins, sans-serif",
            color: "rgba(78, 86, 109, 1)",
            display: "flex",
            justifyContent: "center",
            textAlign: "center",
          }}
        >
        One flat fee, built by an expert team, delivered in just 3 days. Increase sales and customer engagement with photorealistic renderings and animations.
        </p>

    <div style={{ display: "flex", justifyContent: "center",  }}>
      <div style={boxStyles}>
        
      <Grid container style={{  borderRadius: "20px", backgroundImage: 'url("/section7.png")', backgroundColor:"#251d6e", backgroundRepeat:"no-repeat" }}>
        
      <Grid item xs={12} sm={12} md={6} style={{ marginTop: "3rem", padding: "3rem", maxHeight: "350px", marginLeft: "1rem", marginTop: "4rem", backgroundColor: "rgba(255, 255, 255, 0.2)", backdropFilter: "blur(10px)" }}>


        <div style={{display:"flex", alignItems:"center"}}>
        <MailOutlineIcon style={{color:"white", marginRight:"1rem"}}/>
        
        <p style={{color:"white", cursor:"pointer",  fontSize:"16px", fontWeight:"600", fontFamily:"Poppins, sans-serif"}}>
        email@itix.com
        </p>
        </div>

        <br/>

        <div style={{display:"flex", alignItems:"center"}}>
        <PhoneIcon style={{color:"white",  marginRight:"1rem"}}/>
        
        <p style={{color:"white", cursor:"pointer",  fontSize:"16px", fontWeight:"600", fontFamily:"Poppins, sans-serif"}}>
        +423 666 678 809
        </p>
        </div>
        <br/>
        <div style={{display:"flex", alignItems:"center"}}>
        <PlaceIcon style={{color:"white",  marginRight:"1rem"}}/>
    
        <p style={{color:"white", cursor:"pointer",  fontSize:"16px", fontWeight:"600", fontFamily:"Poppins, sans-serif"}}>
        #08, 3rd B Cross, Muneshwar Nagara, Bagalgunte, Bangalore - 560073
        </p>
        </div>

    </Grid>

    <Grid item xs={12} sm={12} md={5} style={{  padding:"1rem", marginTop:"3rem" }}>
        <div>
    <h1>Do you have an idea? </h1>
    <p>Feel free to contact us at any time. We will get back to you as soon as we can.</p>
</div>
       <Grid item xs={12} sm={12} md={6}>
    <h1
          style={{
            fontWeight: "550",
            fontSize: width > 800 ? "16px" : "14px",
            fontFamily: "Poppins, sans-serif",
          }}
        >
         Name
        </h1>
        <input type="text" placeholder="Name" style={{paddingLeft:"1rem", fontSize:"16px",fontFamily: "Poppins, sans-serif", borderRadius:"8px", height:"44px", backgroundColor:"#392b75", width:width>800?"490px":"214px", color:"rgba(36, 36, 54, 1)", border:"1px solid transparent"}}/>

    </Grid>

    <Grid item xs={12} sm={12} md={6}>
    <h1
          style={{
            fontWeight: "550",
            fontSize: width > 800 ? "16px" : "14px",
            fontFamily: "Poppins, sans-serif",
          }}
        >
         Email
        </h1>
        <input type="email" placeholder="Enter your email" style={{paddingLeft:"1rem", fontSize:"16px",fontFamily: "Poppins, sans-serif", borderRadius:"8px", height:"44px", backgroundColor:"#392b75", width:width>800?"490px":"214px", color:"rgba(36, 36, 54, 1)", border:"1px solid transparent"}}/>

    </Grid>
    
    <Grid item xs={12} sm={12} md={6} >
        <h1
          style={{
            fontWeight: "550",
            fontSize: width > 800 ? "16px" : "14px",
            fontFamily: "Poppins, sans-serif",
           
          }}
        >
         Message
        </h1>
        <input type="text" placeholder="Message..." style={{ backgroundColor:"#392b75",paddingLeft:"1rem", fontSize:"16px",fontFamily: "Poppins, sans-serif", borderRadius:"8px", height:"156px", width:width>800?"490px":"214px", color:"rgba(36, 36, 54, 1)", border:"1px solid transparent"}}/>

    </Grid>
    
    
    <br/>
   
    <button style={{textAlign:"center", cursor:"pointer", background:"rgba(86, 63, 216, 1)", fontSize:"14px", fontWeight:"600",fontFamily: "Poppins, sans-serif", borderRadius:"8px", height:"44px", backgroundColor:"#3e64f5", width:width>800?"510px":"235px", color:"white", border:"1px solid transparent"}}>
       Submit
    </button>

    </Grid>

    </Grid>
      </div>
    </div>
      </div>
    </section>
  );
}

export default Contact;
