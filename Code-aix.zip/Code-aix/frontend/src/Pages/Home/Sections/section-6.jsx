import React, {useState,useEffect} from 'react';
import { Grid } from '@mui/material';



function Section6() {
    const [width, setWidth] = useState(window.innerWidth);
  

    const updateDimensions = () => {
      setWidth(window.innerWidth);
    };
    useEffect(() => {
      window.addEventListener("resize", updateDimensions);
      return () => window.removeEventListener("resize", updateDimensions);
    }, []);


    return (

        <div style={{paddingLeft:width>800?"6rem":"2rem", background:"#010408", paddingRight:width>800?"6rem":"2rem", paddingTop:"1rem"}} >
       <Grid container columns={12} columnGap={2}>

        <Grid item sm={12} xs={12} md={12} style={{textAlign:"center"}}>
            <img style={{height:width>800?"300px":"100px", width:width>800?"80vw":"250px"}} src="/section6_1.png" alt="section6 Image" />
        </Grid>
        <br/>
        <br/>
        <Grid item sm={12} xs={12} md={12} style={{textAlign:"center"}}>
        <img style={{height:width>800?"300px":"100px", width:width>800?"80vw":"250px"}} src="/section6_1.png" alt="section6 Image" />
        </Grid>

       </Grid>

      
     
       </div>
    )
}


export default Section6;