// Your React component
import { Grid } from "@mui/material";
import React from "react";
import "./Home.css";
import Menu from "../../Global-Components/Menu";
import GroupsIcon from '@mui/icons-material/Groups';
import { useSelector } from 'react-redux';


function HomePage() {
  const language = useSelector((state) => state.language.language);

  return (
    <div style={{ minHeight: "100vh",  backgroundImage: 'url("/bg-1.PNG")' ,minWidth:"98.9vw", minHeight:"100vh", backgroundSize:"cover", backgroundPosition:"center", backgroundRepeat:"no-repeat", zIndex:-1}}>
      <div
        style={{
          width: 638,
          height: 637,
          position: "absolute",
          zIndex: -1,
          background: "rgba(47.02, 21, 244, 0.50)",
          boxShadow: "700px 700px 700px ",
          borderRadius: 9999,
          filter: "blur(700px)",
        }}
      />
      <div style={{ paddingTop: "4rem", padding: "6rem" }}>
        <h1
          style={{
            color: "#3e63f5",
            fontSize: "60px",
            fontWeight: "700",
            fontFamily: "sans-serif, inter",
          }}
        >
          AIX <span style={{ color: "rgba(255, 255, 255, 1)" }}> AI Tools</span>
        </h1>

        <p
          style={{
            fontWeight: "700",
            fontSize: "24px",
            fontFamily: "sans-serif, inter",
            color: "#FFF",
          }}
        >
          Startup Support and development
        </p>
        {language === 'English' ? (
        <p style={{color:"#A0AEC0", fontSize:"18px"}}>
          ITIX is a technology company with the goal of creating and supporting
          <br />
          STARTUPS with the possibility of tokenization and the use of 21st-century technologies
        </p>
      ) : language === 'Slovakia' ? (
        <p style={{color:"#A0AEC0", fontSize:"18px"}}>
          ITIX je technologická spoločnosť s cieľom tvoriť a podporovať
          <br />
          STARTUPY s možnosťou tokenizácie a využitia technológií 21. storočia
        </p>
      ) : (
        // Default content if language is not English or Slovak
        'Unsupported Language'
      )}


    
        <div
          style={{ display: "flex", flexDirection: "row", marginTop: "3rem" }}
        >
          <button
            style={{
              width: "206px", // Adjust the width as needed
              height: "50px", // Adjust the height as needed
              padding: "10px 20px",
              background: "linear-gradient(112deg, #4587F6 0%, #2F15F4 94%)",
              borderRadius: "8px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: "10px",
              color: "white",
              fontSize: "16px", // Adjust the font size as needed
              fontFamily: "Inter",
              fontWeight: "600",
              wordWrap: "break-word",
              cursor: "pointer",
              fontFamily: "sans-serif, inter",
            }}
          >
            Button
          </button>

          <button
            style={{
              width: "206px", // Adjust the width as needed
              height: "50px", // Adjust the height as needed
              padding: "10px 20px",
              border: "2px solid #4587F6",
              borderRadius: "8px",
              background: "transparent",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: "10px",
              color: "white",
              fontSize: "16px", // Adjust the font size as needed
              fontFamily: "Inter",
              fontWeight: "600",
              wordWrap: "break-word",
              marginLeft: "1rem",
              cursor: "pointer",
              fontFamily: "sans-serif, inter",
            }}
          >
            Button
          </button>
        </div>

        <Grid container spacing={1}
        style={{display:"flex", flexDirection:"row", alignItems:"center", marginTop:"3rem"}}
        >
        <Grid item xs={12} md={2.5} sm={12}>
        <div style={{display:"flex", flexDirection:"row", alignItems:"center", }}>
<div style={{width: 78, height: 78, background: '#0D0D2B', boxShadow: '4px 7px 8px rgba(0, 0, 0, 0.75)', borderRadius: 10, justifyContent: 'center', alignItems: 'center', display: 'inline-flex'}}>
  <GroupsIcon style={{width:"47px", height:"35px",color:"#2F15F4"}}/>
</div>
<div style={{marginLeft:"1.5em"}}>
<h1 style={{
            fontWeight: "700",
            fontSize: "30px",
            fontFamily: "sans-serif, inter",
            color: "rgba(255, 255, 255, 1)",
          }}>10K</h1>

<p   style={{
            fontWeight: "400",
            fontSize: "16px",
            fontFamily: "sans-serif, inter",
            color: "#A0AEC0",
            marginTop:"-0.5rem"
          }}>Používateľov</p>
</div>
</div>
        </Grid> 

        <Grid item xs={12} md={2.5} sm={12}>
        <div style={{display:"flex", flexDirection:"row", alignItems:"center",}}>
<div style={{width: 78, height: 78, background: '#0D0D2B', boxShadow: '4px 7px 8px rgba(0, 0, 0, 0.75)', borderRadius: 10, justifyContent: 'center', alignItems: 'center', display: 'inline-flex'}}>
<img src='/collection-icon.png' style={{width:"47px", height:"35px",color:"#2F15F4"}}/>

</div>
<div style={{marginLeft:"1.5em"}}>
<h1 style={{
            fontWeight: "700",
            fontSize: "30px",
            fontFamily: "sans-serif, inter",
            color: "rgba(255, 255, 255, 1)",
          }}>6+</h1>

<p   style={{
            fontWeight: "400",
            fontSize: "16px",
            fontFamily: "sans-serif, inter",
            color: "#A0AEC0",
            marginTop:"-0.5rem"
          }}>Funkcií</p>
</div>
</div>
     
        </Grid>
        
      </Grid>
</div>
</div>
  );
}

export default HomePage;
