import { Grid } from "@mui/material";
import React from "react";
import HomePage from "./Home";
import Section2 from "./Sections/sections-2";
import "./Main.css";
import Section3 from "./Sections/section-3";
import MySection4 from "./Sections/section-4";
import Section6 from "./Sections/section-6";
import Contact from "./Sections/section7";
import Footer from "./Sections/footer";

function MainPage() {

    return (
        <div className="main-container">
            <section className="section">
            <HomePage />
            </section>
           
           <section  className="section">
            <Section2 />
            </section>

            <section  className="section">
            <Section3 />
            </section>

            <section  className="section">
            <MySection4 />
            </section>

            <section  className="section">
            <Section6 />
            </section>

            <section  className="section">
            <Contact />
            </section>

            <section  className="section">
            <Footer />
            </section>
        </div>
    )
}

export default MainPage;