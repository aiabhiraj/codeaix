import React, { useState, useEffect, useRef } from "react";
import styled from "styled-components";
import { Configuration, OpenAIApi } from "openai";
import { Helmet } from "react-helmet";
import CircleIcon from '@mui/icons-material/Circle';

const ChatContainer = styled.div`
  width: 600px;
  height: 500px;
  border-radius: 8px;
  background-color: #f8f8f8;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  
`;

const ChatHeader = styled.div`
  padding: 10px;
  background-color: #dcdcdc;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  font-size: 15px;
  font-weight: 600;
  color: #333333;
  font-family: "Montserrat", sans-serif;
`;

const ChatContent = styled.div`
  height: calc(100% - 170px);
  padding: 16px;
  overflow-y: auto;
`;

const ChatMessage = styled.div`
  display: flex;
  justify-content: ${(props) => (props.isUser ? "flex-end" : "flex-start")};
  margin-bottom: 8px;
`;

const ChatBubble = styled.div`
  max-width: 70%;
  padding: 6px;
  border-radius: 8px;
  font-size: 15px;
  background-color: ${(props) => (props.isUser ? "#dcdcdc" : "#f1f1f1")};
  color: ${(props) => (props.isUser ? "#333333" : "#333333")};
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
`;

const ChatInputContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 16px;
  background-color: #dcdcdc;
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
`;

const ChatInput = styled.input`
  flex: 1;
  height: 25px;
  padding: 8px;
  border: none;
  border-radius: 4px;
  background-color: #ffffff;

`;

const ChatButton = styled.button`
  margin-left: 16px;
  padding: 3px 3px;
  background-color: #333333;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
`;

function Logo() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [displayText, setDisplayText] = useState("");
  const [loading, setLoading] = useState(false);

  const text =
    "    Create logos here  ";


    const [isLightOn, setIsLightOn] = useState(true);

    useEffect(() => {
      const interval = setInterval(() => {
        setIsLightOn((prevIsLightOn) => !prevIsLightOn);
      }, 1000);
  
      return () => clearInterval(interval);
    }, []);

  const color = isLightOn ? 'green' : 'darkgrey';
  const style = {
    color,
    width: '15px',
    height: '15px',
  };

  useEffect(() => {
    let currentIndex = 0;
    const typingInterval = setInterval(() => {
      setDisplayText((prevText) => prevText + text[currentIndex]);
      currentIndex++;
      if (currentIndex === text.length) {
        clearInterval(typingInterval);
      }
    }, 20);

    return () => {
      clearInterval(typingInterval);
    };
  }, []);

  const chatContentRef = useRef(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    chatContentRef.current.scrollTop = chatContentRef.current.scrollHeight;
  };

  const handleInputChange = (event) => {
    setInputText(event.target.value);
  };

  const handleSendMessage = () => {
    if (inputText.trim() !== "") {
      const newMessage = {
        content: inputText.trim(),
        isUser: true,
      };
      setMessages((prevMessages) => [...prevMessages, newMessage]);
      setInputText("");
      sendBotMessage(newMessage.content);
    }
  };

  const sendBotMessage = async (userMessage) => {
    setLoading(true)
    const configuration = new Configuration({
      apiKey: "key here",
    });
    const openai = new OpenAIApi(configuration);

    try {
      const result = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        temperature: 0.75,
        messages: [{ role: "user", content: userMessage }],
      });

      const botMessage = {
        content: result?.data?.choices[0]?.message?.content,
        isUser: false,
      };

      setMessages((prevMessages) => [...prevMessages, botMessage]);
      setLoading(false)
    } catch (error) {
      console.log(error);
    }
  };
  const configuration = new Configuration({
    apiKey: "key here",
  });
  const openai = new OpenAIApi(configuration);

  const sendDALLERequest = async (userMessage) => {
    setLoading(true);
  

    try {
      const result = await openai.createCompletion({
        engine: "image-alpha-001", // DALL·E model
        prompt: userMessage,
        max_tokens: 1, // Limit the response to a single token
      });
    
      const imageBase64 = result?.data?.choices[0]?.text;
    
      if (imageBase64) {
        // Create a message with the image (base64)
        const botMessage = {
          content: <img src={`data:image/png;base64, ${imageBase64}`} alt="Generated Image" />,
          isUser: false,
        };
    
        setMessages((prevMessages) => [...prevMessages, botMessage]);
      } else {
        // Handle error or show a message if no image is generated
        const errorMessage = {
          content: "I'm sorry, I couldn't generate an image for that input.",
          isUser: false,
        };
    
        setMessages((prevMessages) => [...prevMessages, errorMessage]);
      }
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
    
  };


  const [result, setResult] = useState("");

const generateImage = async () => {
  setLoading(true);

    const res = await openai.createImage({
      prompt: inputText,
      n: 1,
      size: "256x256",
    });
    setLoading(false);

    setResult(res.data.data[0].url);
  };


  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          paddingTop:"1.5rem",
          paddingLeft: "1rem",
          paddingRight: "1rem",
        }}
      >
        <ChatContainer>
          <ChatHeader>Create logo <span style={{display:"flex", justifyContent:"flex-end", marginTop:"-1rem"}}><CircleIcon style={{color:"green", width:"15px", height:"15px"}}/>Live </span></ChatHeader>

          <ChatContent ref={chatContentRef}>
            {messages.length === 0 ? (
              <div
                style={{
                  borderRadius: "8px",
                  textAlign: "justify",
                  maxWidth: "600px",
                  backgroundColor: "#dcdcdc",
                  boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
                }}
              >
                <p
                  style={{
                    color: "black",
                    borderRadius: "5px",
                    paddingLeft: "1rem",
                    paddingRight: "1rem",
                  }}
                >
                  {displayText}
                </p>
              </div>
            ) : null}
            {messages.map((message, index) => (
              <ChatMessage key={index} isUser={message.isUser}>
                <ChatBubble isUser={message.isUser}>
                  {message.content}
                </ChatBubble>
              </ChatMessage>
            ))}

           {result.length > 0 ? (
  <div>
    <img className="result-image" src={result} alt="result" />
    <a
      href={result}
      download="result.png" // You can specify the file name here
    >
      <button>Download Image</button>
    </a>
  </div>
) : null}

       {loading?<img style={{display:"flex", justifyContent:"center", height:"150px", width:"150px", justifyItems:"center"}} src='/bot.gif' />:null}

          </ChatContent>
          <br/>
          <ChatInputContainer>
            <ChatInput
              type="text"
              value={inputText}
              onChange={handleInputChange}
              placeholder="Type a message..."
            />
            {/* <ChatButton onClick={handleSendMessage}>Send</ChatButton> */}
            <ChatButton onClick={()=>generateImage()}>Create Logo</ChatButton>
          </ChatInputContainer>
          
        </ChatContainer>

        <ChatInputContainer>
     

    </ChatInputContainer>
      </div>

      
    </>
  );
}

export default Logo;
