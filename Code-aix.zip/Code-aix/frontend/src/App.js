import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Home from './Pages/Home/Home';
import Menu from './Global-Components/Menu';
import'./App.css';
import MainPage from './Pages/Home/Main';
import Login from './Global-Components/login';
import ResponsiveDrawer from './Global-Components/SideBar';
import Dashboard from './Pages/Account/Dashboard';
import Chat from './Pages/Account/Chat';
import Blog from './Pages/Account/Blog';
import Logo from './Pages/Account/Logo';
import Translate from './Pages/Account/Translate';
import Others from './Pages/Account/others';

const RenderRouterWithSideBar = (Component) => (
  <>
    <ResponsiveDrawer component={<Component />}/>
  </>
);


const RenderRouterWithNav = (Component) => (
  <div  >
   <Menu />
    <Component />

  </div>
);



const LoggedInRoutes = () => (
  <>
    <Routes>
      <Route path="/" element={RenderRouterWithNav(MainPage)} />
      <Route path="/dashboard" element={RenderRouterWithSideBar(Dashboard)} />
      <Route path="/chat" element={RenderRouterWithSideBar(Chat)} />
      <Route path="/blog" element={RenderRouterWithSideBar(Blog)} />
      <Route path="/logo" element={RenderRouterWithSideBar(Logo)} />
      <Route path="/translate" element={RenderRouterWithSideBar(Translate)} />
      <Route path="/others" element={RenderRouterWithSideBar(Others)} />


    </Routes>
  </>
);

const NotLoggedInRoutes = () => (
  <>

    <Routes>
    <Route path="/" element={RenderRouterWithNav(MainPage)} />
    <Route path="/auth" element={RenderRouterWithNav(Login)} />

    </Routes>

  </>
);

function AppRoutes() {
  const { user } = useSelector((state) => state.auth);

  return (
    <BrowserRouter>
      {user ? <LoggedInRoutes /> : <NotLoggedInRoutes />}
    </BrowserRouter>
  );
}

export default AppRoutes;
