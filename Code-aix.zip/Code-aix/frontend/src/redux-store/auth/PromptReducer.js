// reducers.js
import { SET_PROMPT_TEXT } from './actions';

const initialState = {
  promptText: '',
};

const promptReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_PROMPT_TEXT:
      return {
        ...state,
        promptText: action.payload,
      };
    default:
      return state;
  }
};

export default promptReducer;
