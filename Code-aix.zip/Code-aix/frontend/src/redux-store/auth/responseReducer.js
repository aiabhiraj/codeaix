// reducers.js
import { SET_RESPONSE_TEXT } from './actions';

const initialState = {
  responseText: '',
};

const responseReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_RESPONSE_TEXT:
      return {
        ...state,
        responseText: action.payload,
      };
    default:
      return state;
  }
};

export default responseReducer;
