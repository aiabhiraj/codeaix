// export * as globalActions from './global/actions'
export * as authActions from './auth/actions'


// export { default as globalReducer } from './global/reducer'
export { default as authReducer } from './auth/reducer'

