import axios from 'axios'

const backend = axios.create({
  baseURL:
    process.env.NODE_ENV === 'production'
      ? 'localhost:8080'
      : 'localhost:8080',
})

backend.interceptors.request.use(
  (config) => {
    let user = ''
    if (!user)
      user = localStorage.getItem('user')
        ? JSON.parse(localStorage.getItem('user'))
        : null
    if (user) config.headers = { Authorization: `Bearer ${user.token}` }
    return config
  },
  (error) => Promise.reject(error)
)

export default backend
